var haystackText = "";
function findMyText(needle, replacement) {
     if (haystackText.length == 0) {
          haystackText = document.getElementById("haystack").innerHTML;
     }
     var match = new RegExp(needle, "ig");     
     var replaced = "";
     if (replacement.length > 0) {
          replaced = haystackText.replace(match, replacement);
     }
     else {
          var boldText = "<div style=\"background-color: yellow; display: inline; font-weight: bold;\">" + needle + "</div>";
          replaced = haystackText.replace(match, boldText);
     }
     document.getElementById("haystack").innerHTML = replaced;
}

	 $(document).ready(function() { 
	  $("#haystack" ).click(function(event){
              
			  $("#pop").css("display" ,"block");
               
               });	  
			   
			   
			   $("#close" ).click(function(event){
              
			  $("#pop").css("display" ,"none");

               });
			   
	 
	  $("#co").click(function(event){
               $.getJSON('QuestionJSON.json', function(jd) {
                  $('#haystack').html('<p>' + jd.properties.text + '</p>');

               });
			  				  
				var json_obj=   $.getJSON('AnswerJSON.json', function(data) {
					  alert(JSON.stringify(json_obj));
					   
			  	});	   
            });
	 
	 
		$('#incfont').click(function(){	   
        curSize= parseInt($('#haystack').css('font-size')) + 2;
		if(curSize<=20)
        $('#haystack').css('font-size', curSize);
        });  
		$('#decfont').click(function(){	   
        curSize= parseInt($('#haystack').css('font-size')) - 2;
		if(curSize>=12)
        $('#haystack').css('font-size', curSize);
        }); 
	});